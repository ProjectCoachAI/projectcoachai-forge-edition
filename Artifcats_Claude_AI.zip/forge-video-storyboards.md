# ProjectCoach AI Forge - Video Marketing Storyboards
## For Hera AI Video Generation

---

## VIDEO 1: "Stop Juggling Browser Tabs" (Hero Video)
**Duration:** 15-20 seconds  
**Platform:** TikTok, Instagram Reels, X  
**Style:** Dynamic, problem-solution, eye-catching

### Hera Prompt:
```
Create a modern tech product video with dark navy blue background. Start with animated browser tab icons (colorful circles with AI logos) floating chaotically across the screen, juggling and bouncing. Show text "Stop Juggling 15 Browser Tabs" with "15 Browser Tabs" in bold orange gradient. Browser tabs gradually organize and merge into a single sleek application window showing the ProjectCoach AI Forge logo (orange flame icon). End with text "Forge: Your AI Control Center" and "Download Free Now" button with download icon. Include subtle particle effects and smooth transitions. Professional, clean, modern aesthetic.
```

### Scene Breakdown:
1. **0-3s:** Floating, chaotic browser tabs (blues, purples, greens, reds)
2. **3-6s:** Text appears: "Stop Juggling 15 Browser Tabs"
3. **6-9s:** Tabs converge into single Forge window
4. **9-12s:** Forge interface preview appears
5. **12-15s:** CTA: "Download Free Now" + website

### Visual Elements:
- Dark navy background (#0a0f1e)
- Orange accent color (#ff6b35)
- Floating AI logos: ChatGPT 🤖, Claude 🔮, Gemini ✨, Perplexity 🔍
- Smooth motion blur effects
- Particle transitions

---

## VIDEO 2: "Quick Chat Feature" (Product Demo)
**Duration:** 20-25 seconds  
**Platform:** All platforms  
**Style:** Product showcase, UI animation

### Hera Prompt:
```
Modern tech product demo video. Dark background. Show a sleek application interface titled "Quick Chat - Forge Edition". Animate a dropdown selector opening to reveal AI chatbot options: ChatGPT, Claude, Gemini, Perplexity with colorful logos and gradient backgrounds. User clicks to select Claude (orange/brown gradient with crystal ball emoji). Interface smoothly transitions to chat window. Show typing animation of a question "What's the best way to learn Python?" followed by AI response appearing with smooth fade-in. Display AI selector badges showing "8 AIs Available" with orange gradient highlight. End with "Switch AIs Instantly" tagline. Clean, professional, modern UI design.
```

### Scene Breakdown:
1. **0-4s:** Forge app opens, Quick Chat mode highlighted
2. **4-8s:** AI selector dropdown animates open
3. **8-12s:** Showcase 4 AI options with logos
4. **12-16s:** Select Claude, chat interface appears
5. **16-20s:** Show instant switching between AIs
6. **20-25s:** CTA: "Download Forge Free"

### Visual Elements:
- Modern UI with gradient buttons
- Orange selection highlights
- Emoji AI avatars
- Smooth transition effects
- Typing cursor animation

---

## VIDEO 3: "Multi-Pane Comparison" (Power Feature)
**Duration:** 25-30 seconds  
**Platform:** Instagram, X (longer format)  
**Style:** Comparison showcase, split-screen

### Hera Prompt:
```
Professional tech product video showcasing AI comparison feature. Start with single chat window, then split into 4 quadrants showing ChatGPT, Claude, Gemini, and Perplexity responding simultaneously to the same question "Where is the polar circle?". Each quadrant has distinct AI branding colors: ChatGPT (teal), Claude (orange), Gemini (blue/green), Perplexity (cyan). Show text responses appearing synchronously in each panel. Highlight ranking indicators (gold stars) appearing above each response: Claude gets 3 stars, others get 2. Then show a synthesis panel merging all answers with orange gradient "Best of All AIs" header. End with "Compare 4+ AIs in 30 Seconds" tagline. Modern, clean interface with subtle shadows and borders.
```

### Scene Breakdown:
1. **0-5s:** Single question entered
2. **5-10s:** Screen splits into 4 panels
3. **10-15s:** All 4 AIs respond simultaneously
4. **15-20s:** Auto-ranking appears (stars/scores)
5. **20-25s:** Synthesis panel shows combined answer
6. **25-30s:** CTA with stats: "94% User Confidence"

### Visual Elements:
- 4-pane split layout
- Color-coded AI responses
- Star rating system
- Synthesis animation
- Data visualization

---

## VIDEO 4: "The Problem Everyone Has" (Before/After)
**Duration:** 20 seconds  
**Platform:** TikTok, Instagram Reels  
**Style:** Problem-solution, relatable

### Hera Prompt:
```
Split-screen comparison video. LEFT SIDE labeled "The Old Way" with frustrated emoji 😰 shows messy desktop with 15+ browser tabs (Chrome, Safari) open simultaneously, each with different AI chatbot. Red X marks appear, timer shows "45 minutes wasted". RIGHT SIDE labeled "The New Way (With Forge)" with happy emoji 😌 shows clean Forge application window with organized AI selector, green checkmarks appearing, timer shows "30 seconds". Orange arrow points from left to right. End with text "Result: Confident decisions, move forward" with orange gradient. Dark background, modern minimalist design.
```

### Scene Breakdown:
1. **0-4s:** Split screen appears, labels show
2. **4-8s:** LEFT: Chaos animation (multiple tabs)
3. **8-12s:** RIGHT: Forge clean interface
4. **12-16s:** Time comparison (45min vs 30sec)
5. **16-20s:** Results and CTA

### Visual Elements:
- Side-by-side comparison
- Red (problem) vs Green (solution)
- Timer animations
- Emoji reactions
- Orange directional arrow

---

## VIDEO 5: "15+ AI Models" (Feature Showcase)
**Duration:** 15 seconds  
**Platform:** TikTok, Instagram Stories  
**Style:** Quick, punchy, logo showcase

### Hera Prompt:
```
Dynamic tech showcase video. Dark navy background with floating AI brand logos appearing one by one in a circular pattern: ChatGPT 🤖, Claude 🔮, Gemini ✨, Perplexity 🔍, Grok 🚀, Mistral 🎯, DeepSeek 🌟, POE 💡, and more. Each logo has colorful gradient backgrounds and subtle glow effects. Logos orbit around center text "15+ AI Models" in large orange gradient font. Then all logos zoom into Forge app icon in center. End with "All in One App" tagline and orange "Download Free" button. Particle effects, smooth animations, modern premium feel.
```

### Scene Breakdown:
1. **0-3s:** AI logos appear one by one
2. **3-6s:** Form circular orbit pattern
3. **6-9s:** "15+ AI Models" text appears
4. **9-12s:** Logos converge into Forge icon
5. **12-15s:** CTA appears

### Visual Elements:
- Colorful AI brand logos
- Circular orbit animation
- Orange gradient text
- Particle effects
- Glow/lighting effects

---

## VIDEO 6: "30 Seconds to Confident Decisions" (Testimonial Style)
**Duration:** 20-25 seconds  
**Platform:** LinkedIn, X, Instagram  
**Style:** Stats-driven, professional

### Hera Prompt:
```
Professional corporate video with dark background. Animated statistics appearing with smooth scale-in effects: "15+ AI Models Supported" with robot icon, "10K+ Comparisons Run" with chart icon, "30s Average Decision Time" with stopwatch icon, "94% User Confidence" with trophy icon. Each stat appears in large orange gradient numbers with supporting text. Include testimonial quote cards sliding in: "I was wasting 45 minutes every day comparing AI responses manually. Forge gives me auto-ranked results in 30 seconds." - Sarah Chen, Product Manager, Stripe. End with Forge logo and "Join Thousands Making Confident AI Decisions" tagline. Clean, modern, data-driven aesthetic.
```

### Scene Breakdown:
1. **0-5s:** Stats appear one by one
2. **5-12s:** Testimonial card slides in
3. **12-18s:** Show before/after time comparison
4. **18-25s:** CTA with social proof

### Visual Elements:
- Large numerical stats
- Icon animations
- Testimonial cards
- Orange gradient highlights
- Professional typography

---

## VIDEO 7: "Free Forever" (Pricing Focus)
**Duration:** 15 seconds  
**Platform:** All platforms  
**Style:** Simple, direct, trust-building

### Hera Prompt:
```
Clean minimalist video. Dark background. Large text "Start Free. Scale When Ready." appears with smooth fade-in. Show animated pricing cards appearing: "Starter $0 Forever Free" highlighted with green checkmarks for features like "Unlimited comparisons", "All AI models", "30 syntheses/month". Orange badge says "No Credit Card Required". Then show upgrade options sliding in: Creator $14.95, Professional $34.95, Team $59.95. End with "Try Forge Free Today" button with download icon. Transparent, trustworthy, modern design with subtle gradient accents.
```

### Scene Breakdown:
1. **0-3s:** "Start Free" headline
2. **3-8s:** Free tier features appear
3. **8-12s:** Upgrade tiers slide in
4. **12-15s:** CTA button pulses

### Visual Elements:
- Pricing card animations
- Green checkmarks
- Orange CTA button
- Trust badges
- Clean typography

---

## VIDEO 8: "Quick Switch Demo" (UI Interaction)
**Duration:** 10 seconds  
**Platform:** TikTok, Instagram Stories (Short form)  
**Style:** Fast-paced, UI focused

### Hera Prompt:
```
Fast-paced UI demo video. Show Forge Quick Chat interface with prominent AI selector. Cursor clicks dropdown, revealing grid of 8 colorful AI options. Quick succession of selections: ChatGPT → Claude → Gemini → Perplexity, each switch takes 0.5 seconds with smooth transitions and color changes. Each AI has distinct gradient background and emoji icon. Text overlay: "Switch AIs Instantly" with timer showing "0.5s per switch". End with "One App. Every AI. Your Choice." tagline. Modern, snappy, dynamic editing with motion blur effects.
```

### Scene Breakdown:
1. **0-2s:** Show AI selector
2. **2-7s:** Rapid AI switching demonstration
3. **7-10s:** Tagline and CTA

### Visual Elements:
- Quick cuts
- Motion blur transitions
- Timer overlay
- Color transitions
- Fast-paced energy

---

## STYLE GUIDELINES FOR ALL VIDEOS

### Color Palette:
- **Primary Background:** #0a0f1e (Dark Navy)
- **Secondary Background:** #111827 (Dark Gray)
- **Primary Accent:** #ff6b35 (Orange)
- **Secondary Accent:** #00d4ff (Cyan)
- **Success Green:** #10b981
- **Text Primary:** #ffffff (White)
- **Text Secondary:** #9ca3af (Gray)

### Typography:
- **Headers:** Syne Bold/Extra Bold (800 weight)
- **Body:** DM Sans (400-600 weight)
- **Style:** Modern, clean, tech-forward

### Animation Style:
- Smooth, professional transitions
- 0.3-0.5s duration for most animations
- Easing: ease-in-out
- Subtle particle effects
- No harsh cuts

### Branding Elements:
- **Logo:** Orange flame icon 🔥
- **Tagline:** "Your AI Control Center"
- **CTA:** "Download Forge Free"
- **Website:** projectcoach.ai (or actual URL)

### AI Brand Colors:
- **ChatGPT:** Teal gradient (#10a37f → #1a7f64)
- **Claude:** Orange/Brown (#d97757 → #b85c3f)
- **Gemini:** Blue/Green (#4285f4 → #34a853)
- **Perplexity:** Cyan (#1fb6ff → #0891b2)
- **Grok:** Red/Pink (#ff6b6b → #ee5a6f)
- **Mistral:** Purple (#667eea → #764ba2)
- **DeepSeek:** Orange/Yellow (#ff9500 → #ff6b00)
- **POE:** Pink/Purple (#f093fb → #f5576c)

---

## PLATFORM-SPECIFIC RECOMMENDATIONS

### TikTok (9:16 vertical):
- Use Videos: 1, 2, 4, 5, 8
- Hook in first 2 seconds
- Text overlays required (most watch without sound)
- Keep under 20 seconds
- Fast-paced editing

### Instagram Reels (9:16 vertical):
- Use Videos: 1, 2, 4, 5, 6, 8
- Similar to TikTok but can be 20-30s
- Clean, aesthetic focus
- Emphasize visual appeal
- Include captions

### Instagram Stories (9:16 vertical):
- Use Videos: 5, 7, 8
- 15 seconds max
- Simple, direct message
- Swipe-up CTA (if available)
- Poll/question stickers

### X/Twitter (16:9 or 1:1):
- Use Videos: 1, 3, 6, 7
- 20-45 seconds ideal
- Professional tone
- Tech-focused audience
- Include subtitles

### LinkedIn (16:9):
- Use Videos: 3, 6, 7
- Professional style
- Testimonials work well
- Business value focus
- 30-60 seconds

---

## CALL-TO-ACTION OPTIONS

### Primary CTAs:
1. "Download Forge Free" → projectcoach.ai
2. "Try Free - No Credit Card" → Download page
3. "Join 10,000+ Users" → Social proof + link
4. "Start Comparing AIs Now" → Action-focused

### Secondary CTAs:
1. "Learn More" → Features page
2. "See Pricing" → Pricing page
3. "Watch Demo" → Full demo video
4. "Follow for Updates" → Social follow

---

## TESTING & OPTIMIZATION

### A/B Test Elements:
- Hook: Problem-focused vs Feature-focused
- Length: 10s vs 20s vs 30s
- CTA: "Download" vs "Try Free" vs "Get Started"
- Style: Fast-paced vs Smooth/elegant
- Voiceover: Yes vs No (text only)

### Success Metrics:
- View completion rate (>60% is good)
- Click-through rate (>2% is good)
- Engagement rate (likes, comments, shares)
- Website visits from video
- Download conversions

---

## PRODUCTION TIPS FOR HERA

1. **Be Specific:** Include exact colors, positions, and timings
2. **Reference Style:** "Make it Nintendo style" or "Modern tech commercial"
3. **Emphasize Motion:** Describe how elements move, not just what they look like
4. **Layer Complexity:** Start simple, add details in iterations
5. **Use Keywords:** "Smooth," "modern," "professional," "dynamic," "clean"

### Example Prompt Structure:
```
[Opening scene description] → [Main action/transition] → [Key elements and colors] → [Ending/CTA] → [Overall style/mood]
```

### Refinement Prompts:
After generating initial video:
- "Make the colors more vibrant"
- "Speed up the transitions"
- "Add rainbow colors to the AI logos"
- "Make the text larger and bolder"
- "Add particle effects to the background"

---

## CONTENT CALENDAR SUGGESTION

### Week 1:
- Mon: Video 1 (Stop Juggling Tabs)
- Wed: Video 5 (15+ AI Models)
- Fri: Video 8 (Quick Switch Demo)

### Week 2:
- Mon: Video 4 (Before/After)
- Wed: Video 2 (Quick Chat)
- Fri: Video 7 (Free Forever)

### Week 3:
- Mon: Video 3 (Multi-Pane)
- Wed: Video 6 (Testimonials)
- Fri: User-generated content / Behind-scenes

### Week 4:
- Remix best-performing videos
- Create variations with different CTAs
- Test new formats

---

## NOTES

- Save all Hera projects with clear naming: "Forge_Video1_StopJuggling_v1"
- Export in multiple aspect ratios: 9:16, 1:1, 16:9
- Keep source prompts for easy iteration
- A/B test different hooks and CTAs
- Monitor analytics to identify best performers
- Repurpose top performers with slight variations

Good luck with your video marketing! 🎬🔥
